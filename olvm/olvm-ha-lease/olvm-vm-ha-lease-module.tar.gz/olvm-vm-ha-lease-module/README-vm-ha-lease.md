# OLVM VM High Availability + Lease module

Roadmap item **#3 (data integrity / anti-split-brain)** for the
`olvm-ha-tuning` project. It enables **High Availability** and assigns a
**storage lease** to your critical VMs in OLVM / oVirt.

## Why both HA *and* a lease

- **Highly Available** tells the engine to **restart** the VM elsewhere after a
  host failure.
- The **lease** is a small record the running host holds on a shared storage
  domain. It is the **storage-level guard** that stops the *same* VM from being
  started on two hosts at once (split-brain → disk corruption). The engine only
  restarts a leased VM once the lease confirms the old host released it.

Use **both together** for critical VMs. HA without a lease can still risk a
dual-run in a partition; a lease without HA won't auto-restart.

## Zero extra dependencies

Like the rest of this project, it uses **only the ansible-core builtin `uri`
module** against the engine REST API — no `ovirt.ovirt` collection and no
`ovirt-engine-sdk-python`. It runs **from the control node** over HTTPS (443) to
the engine.

## Files

```
olvm-vm-ha-lease.yml        # the playbook (uri-only, idempotent, --check aware)
vars/ha-vms.yml             # list of critical VMs (edit this)
README-vm-ha-lease.md       # this file
```

Drop these next to the existing project so they share the same `inventory*.yml`.

## Prerequisites

- Engine FQDN reachable on 443 from the control node.
- Admin user (default `admin@internal`) + password.
- Each lease storage domain is an **active data domain (V4+)**.
- The VM's disks are on shared storage.

## Secrets (don't hardcode the password)

Keep the engine password in an ansible-vault file:

```bash
ansible-vault create vars/engine-secret.yml      # add: engine_password: 'YOURPASS'
```

## Usage

```bash
# 1) Edit the VM list
vi vars/ha-vms.yml

# 2) Preview (no change) — recommended first
ansible-playbook olvm-vm-ha-lease.yml -i inventory-lab-akyuz.yml \
  -e @vars/ha-vms.yml -e @vars/engine-secret.yml --ask-vault-pass --check

# 3) Apply
ansible-playbook olvm-vm-ha-lease.yml -i inventory-lab-akyuz.yml \
  -e @vars/ha-vms.yml -e @vars/engine-secret.yml --ask-vault-pass

# Self-signed engine cert in a lab? add:
#   -e engine_validate_certs=false
# Trusted CA bundle instead?
#   -e engine_ca_file=/etc/pki/ovirt-engine/ca.pem

# Disable HA again for the listed VMs:
ansible-playbook olvm-vm-ha-lease.yml -i inventory-lab-akyuz.yml \
  -e @vars/ha-vms.yml -e @vars/engine-secret.yml -e ha_state=absent --ask-vault-pass
```

The engine FQDN is taken from the `ovirt_engine` inventory group automatically;
override with `-e engine_fqdn=olvmm.lab.akyuz.tech` if needed.

## What it does (idempotent)

1. Gets an SSO bearer token (`no_log`).
2. Resolves each lease storage-domain name → id (asserts exactly one match).
3. Resolves each VM name → id (asserts exactly one match).
4. Compares current vs desired (HA enabled, priority, lease SD) and updates
   **only** the VMs that differ — a converged re-run changes nothing.
5. Re-reads and prints a per-VM summary.

`--check` performs all read-only lookups and prints the plan without sending any
change.

## VM list format (`vars/ha-vms.yml`)

| Field | Required | Meaning |
|-------|----------|---------|
| `name` | yes | exact VM name in the portal |
| `lease_storage_domain` | yes (present) | active data domain holding the lease |
| `priority` | no (default 50) | HA restart priority 1–100 (≈Low/Medium/High) |
| `resume_behavior` | no | `auto_resume` / `leave_paused` / `kill` on storage I/O error |

`kill` + a lease = fast failover (HA restarts the VM elsewhere). `auto_resume`
rides out short storage blips. Choose per workload.

## Verify in the portal

`Compute > Virtual Machines > <VM> > Edit > High Availability`:
**Highly Available** checked, **Target Storage Domain for VM Lease** set.

> Note: `ha_state=absent` disables HA and attempts to clear the lease, but
> lease-removal semantics vary by engine version — verify in the portal and
> prefer the UI if in doubt. Test HA/lease behaviour with a real failover in a
> maintenance window before relying on it.
